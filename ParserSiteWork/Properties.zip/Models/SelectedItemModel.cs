namespace ParserSiteWork.Models
{
    public class SelectedItemModel
    {
        public string? SelectValue { get; set; }
        public bool SelectTrue { get; set; }
        public string TaskObject { get; set; }
    }
}